package com.example.gamestore.exception;

public class DefaultException extends Exception{
    public DefaultException(String message){
        super(message);
    }
}
