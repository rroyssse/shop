package com.example.gamestore.controller;

import com.example.gamestore.entity.DeviceEntity;
import com.example.gamestore.service.DeviceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/devices")
public class DeviceController {
    @Autowired
    private DeviceService deviceService;

    @PostMapping
    public ResponseEntity createDevice(@RequestBody DeviceEntity device, @RequestParam Long category_id, @RequestHeader("Authorization") String header) {
        try {
            return ResponseEntity.ok(deviceService.createDevice(device, header, category_id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e);
        }
    }

    @GetMapping
    public ResponseEntity getDevice(@RequestParam Long id) {
        try {
            return ResponseEntity.ok(deviceService.getOne(id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Something wrong");
        }
    }

    @GetMapping("/")
    public ResponseEntity getAll() {
        try {
            return ResponseEntity.ok(deviceService.getAll());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity deleteUser(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(deviceService.delete(id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Something wrong!");
        }
    }
}
