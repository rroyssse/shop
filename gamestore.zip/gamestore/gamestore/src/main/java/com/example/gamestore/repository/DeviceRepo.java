package com.example.gamestore.repository;

import com.example.gamestore.entity.DeviceEntity;
import com.example.gamestore.entity.UserEntity;
import org.springframework.data.repository.CrudRepository;

public interface DeviceRepo extends CrudRepository<DeviceEntity, Long> {
    UserEntity findByTitle(String username);
}
