package com.example.gamestore.controller;

import com.example.gamestore.entity.CategoryEntity;
import com.example.gamestore.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/category")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;

    @PostMapping
    public ResponseEntity addCategory(@RequestBody CategoryEntity category){
        System.out.println(category.getName());
        try {
            return ResponseEntity.ok(categoryService.addCategory(category));
        }catch (Exception e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/")
    public ResponseEntity getCategories(){
        try {
            return ResponseEntity.ok(categoryService.getCategories());
        }catch (Exception e){
            return ResponseEntity.badRequest().body("Something wrong!");
        }
    }

    @GetMapping
    public ResponseEntity getOneCategory(@RequestParam Long id){
        try {
            return ResponseEntity.ok(categoryService.getOneCategory(id));
        }catch (Exception e){
            return ResponseEntity.badRequest().body("Something wrong!");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity deleteCategory(@PathVariable Long id){
        try {
            return ResponseEntity.ok(categoryService.deleteCategory(id));
        }catch (Exception e){
            return ResponseEntity.badRequest().body("Something wrong!");
        }
    }

}
