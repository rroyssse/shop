package com.example.gamestore.model;

import com.example.gamestore.entity.DeviceEntity;
import com.example.gamestore.entity.UserEntity;

import java.util.ArrayList;
import java.util.List;

public class User {
    private Long id;
    private String username;
    private List<Device> devices;

    public static User toModel(UserEntity entity){
        User model = new User();
        model.setId(entity.getId());
        model.setUsername(entity.getUsername());


        if(entity.getDevices()!= null) {
            List<DeviceEntity> list = entity.getDevices();
            List<Device> models = new ArrayList<>();
            for (DeviceEntity deviceEntity : list) {
                models.add(Device.toModel(deviceEntity));
            }
            model.setDevices(models);
        }
        return model;
    }

    public User() {
    }

    public List<Device> getDevices() {
        return devices;
    }

    public void setDevices(List<Device> devices) {
        this.devices = devices;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
