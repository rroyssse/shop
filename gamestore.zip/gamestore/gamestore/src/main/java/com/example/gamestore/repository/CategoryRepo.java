package com.example.gamestore.repository;

import com.example.gamestore.entity.CategoryEntity;
import org.springframework.data.repository.CrudRepository;

public interface CategoryRepo extends CrudRepository<CategoryEntity, Long> {
    CategoryEntity findByName(String name);
}
