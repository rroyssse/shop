package com.example.gamestore.service;

import com.example.gamestore.entity.CategoryEntity;
import com.example.gamestore.exception.DefaultException;
import com.example.gamestore.repository.CategoryRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;


@Service
public class CategoryService {

    @Autowired
    private CategoryRepo categoryRepo;

    public CategoryEntity addCategory(CategoryEntity category) throws DefaultException {
        if(categoryRepo.findByName(category.getName()) != null){
            throw new DefaultException("Category already exists");
        }
        CategoryEntity newCategory = categoryRepo.save(category);
        return newCategory;
    }


    public List<CategoryEntity> getCategories(){
        Iterable<CategoryEntity> categories = categoryRepo.findAll();
        List<CategoryEntity> categoriesModels = new ArrayList<>();

        for (CategoryEntity category: categories) {
            categoriesModels.add(category);
        }
        return categoriesModels;
    }

    public CategoryEntity getOneCategory(Long id) throws DefaultException {
        CategoryEntity category = categoryRepo.findById(id).get();
        if(category == null){
            throw new DefaultException("Category not found");
        }
        return category;
    }

    public Long deleteCategory(Long id){
        categoryRepo.deleteById(id);
        return id;
    }

}
