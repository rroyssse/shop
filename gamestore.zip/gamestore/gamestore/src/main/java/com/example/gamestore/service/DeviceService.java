package com.example.gamestore.service;

import com.example.gamestore.entity.CategoryEntity;
import com.example.gamestore.entity.DeviceEntity;
import com.example.gamestore.entity.UserEntity;
import com.example.gamestore.model.Device;
import com.example.gamestore.repository.CategoryRepo;
import com.example.gamestore.repository.DeviceRepo;
import com.example.gamestore.repository.UserRepo;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Service
public class DeviceService {
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private CategoryRepo categoryRepo;
    @Autowired
    private DeviceRepo deviceRepo;

    public Device createDevice(DeviceEntity device, String header, Long category_id) throws ParseException {
        String username = getUsernameFromJWT(header);
        UserEntity user = userRepo.findByUsername(username);

        device.setUser(user);
        System.out.println("current user:" + user.getId());
        CategoryEntity category = categoryRepo.findById(category_id).get();
        device.setCategory(category);
        deviceRepo.save(device);
        return Device.toModel(device);
    }

    public Device getOne(Long id) {
        DeviceEntity device = deviceRepo.findById(id).get();
        return Device.toModel(device);
    }

    public List<Device> getAll() {
        Iterable<DeviceEntity> devices = deviceRepo.findAll();
        List<Device> deviceModels = new ArrayList<>();

        for (DeviceEntity device : devices) {
            deviceModels.add(Device.toModel(device));
        }
        return deviceModels;
    }

    public Long delete(Long id) {
        deviceRepo.deleteById(id);
        return id;
    }

    public String getUsernameFromJWT(String header) throws ParseException {
        String token = header.split("\\s+")[1];
        String[] chunks = token.split("\\.");
        Base64.Decoder decoder = Base64.getDecoder();
        String payload = new String(decoder.decode(chunks[1]));
        String[] tokenParts = payload.split(",");
        String[] tokenNameParts = tokenParts[1].split("\"");
        return tokenNameParts[3];
    }
}
